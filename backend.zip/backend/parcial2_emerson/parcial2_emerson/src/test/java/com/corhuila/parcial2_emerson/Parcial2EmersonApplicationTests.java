package com.corhuila.parcial2_emerson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Parcial2EmersonApplicationTests {

	@Test
	void contextLoads() {
	}

}
