package com.corhuila.parcial2_emerson.IService;

import com.corhuila.parcial2_emerson.Document.Cliente;

import java.util.List;
import java.util.Optional;
public interface IClienteService {

    List<Cliente> findAll();
    Optional<Cliente> findById(String id);
    Cliente save(Cliente cliente);
    void update(Cliente cliente, String id);
    void delete(String id);
}
