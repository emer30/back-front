package com.corhuila.parcial2_emerson.IRepository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import com.corhuila.parcial2_emerson.Document.Cliente;

@Repository
public interface IClienteRepository extends MongoRepository<Cliente, String> {


}
