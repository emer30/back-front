package com.corhuila.parcial2_emerson.IService;

import com.corhuila.parcial2_emerson.Document.Pedido;

import java.util.List;
import java.util.Optional;

public interface IPedidoService {

    List<Pedido> findAll();
    Optional<Pedido> findById(String id);
    Pedido save(Pedido pedido);
    void update(Pedido pedido, String id);
    void delete(String id);
}
