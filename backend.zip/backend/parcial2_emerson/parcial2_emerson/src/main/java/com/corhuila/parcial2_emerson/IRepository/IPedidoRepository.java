package com.corhuila.parcial2_emerson.IRepository;

import com.corhuila.parcial2_emerson.Document.Pedido;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IPedidoRepository extends MongoRepository<Pedido, String> {

}
