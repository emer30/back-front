package com.corhuila.parcial2_emerson.Document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "pedido")
public class Pedido {

    @Id
    private String id;
    @Field
    private String numero_pedido;
    @Field
    private String detalles_producto;
    @Field
    private String cantidad_productos;
    @DBRef
    private Cliente cliente;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumero_pedido() {
        return numero_pedido;
    }

    public void setNumero_pedido(String numero_pedido) {
        this.numero_pedido = numero_pedido;
    }

    public String getDetalles_producto() {
        return detalles_producto;
    }

    public void setDetalles_producto(String detalles_producto) {
        this.detalles_producto = detalles_producto;
    }

    public String getCantidad_productos() {
        return cantidad_productos;
    }

    public void setCantidad_productos(String cantidad_productos) {
        this.cantidad_productos = cantidad_productos;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
